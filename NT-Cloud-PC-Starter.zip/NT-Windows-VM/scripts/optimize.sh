#!/usr/bin/env bash
set -euo pipefail

echo "Limpeza leve do ambiente Linux..."
if command -v apt-get >/dev/null 2>&1; then
  sudo apt-get clean
  sudo apt-get autoremove -y
fi
if [[ -d "${HOME}/.cache" ]]; then
  du -sh "${HOME}/.cache" 2>/dev/null || true
fi
echo "Concluído. Nenhum ajuste de CPU/GPU/RAM foi aplicado."
