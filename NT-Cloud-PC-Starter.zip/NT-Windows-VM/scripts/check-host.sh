#!/usr/bin/env bash
set -euo pipefail

echo "=== NT Cloud PC: diagnóstico do host ==="
echo "Arquitetura: $(uname -m)"
echo "Kernel: $(uname -r)"
echo
echo "CPU:"
if command -v nproc >/dev/null 2>&1; then
  echo "CPUs disponíveis: $(nproc)"
fi
if [[ -r /proc/cpuinfo ]]; then
  grep -m1 -E 'model name|Hardware' /proc/cpuinfo || true
fi
echo
echo "Memória:"
if command -v free >/dev/null 2>&1; then free -h; fi
echo
echo "Disco:"
df -h .
echo
echo "Virtualização:"
if [[ -e /dev/kvm ]]; then
  ls -l /dev/kvm
  if [[ -r /dev/kvm && -w /dev/kvm ]]; then
    echo "KVM parece acessível."
  else
    echo "KVM existe, mas não está acessível para este usuário."
  fi
else
  echo "/dev/kvm não encontrado. Aceleração KVM não está disponível neste ambiente."
fi
echo
for bin in qemu-system-x86_64 qemu-img; do
  if command -v "$bin" >/dev/null 2>&1; then
    printf '%s: %s\n' "$bin" "$(command -v "$bin")"
  else
    printf '%s: não instalado\n' "$bin"
  fi
done
