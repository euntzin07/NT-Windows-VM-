#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ISO="${ROOT_DIR}/vm/windows11.iso"
DISK="${ROOT_DIR}/vm/windows11.qcow2"

echo "=== NT Cloud PC: verificação para iniciar ==="

if ! command -v qemu-system-x86_64 >/dev/null 2>&1; then
  echo "ERRO: qemu-system-x86_64 não está instalado."
  echo "Este script não instala nem baixa o Windows."
  exit 1
fi

if [[ ! -e /dev/kvm || ! -r /dev/kvm || ! -w /dev/kvm ]]; then
  echo "ERRO: KVM não está disponível/acessível. Não é recomendado iniciar uma VM Windows lenta por emulação neste Codespace."
  echo "Use um host Linux/serviço de virtualização que ofereça KVM."
  exit 1
fi

if [[ ! -f "$ISO" ]]; then
  echo "ERRO: ISO não encontrada: $ISO"
  echo "Coloque uma ISO oficial/licenciada do Windows 11 nesse caminho."
  exit 1
fi

if ! command -v qemu-img >/dev/null 2>&1; then
  echo "ERRO: qemu-img não está instalado."
  exit 1
fi

mkdir -p "${ROOT_DIR}/logs"
if [[ ! -f "$DISK" ]]; then
  qemu-img create -f qcow2 "$DISK" 80G
fi

echo "Iniciando instalador do Windows 11..."
exec qemu-system-x86_64 \
  -enable-kvm \
  -machine q35 \
  -cpu host \
  -smp 4 \
  -m 8G \
  -drive "file=${DISK},if=virtio,format=qcow2" \
  -cdrom "$ISO" \
  -boot order=d \
  -display none \
  -serial mon:stdio \
  -vnc 127.0.0.1:0
