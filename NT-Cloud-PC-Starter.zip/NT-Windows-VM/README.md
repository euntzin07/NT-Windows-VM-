# NT Cloud PC — estrutura inicial

Este pacote cria a estrutura inicial do projeto. Ele **não inclui uma cópia do Windows** nem inicia uma VM automaticamente.

## Requisitos e limitações

- GitHub Codespaces normalmente executa dentro de um contêiner Linux.
- A virtualização aninhada/KVM e o acesso a GPU dedicada podem não estar disponíveis.
- Para executar Windows 11, você precisa de uma licença válida e de uma ISO oficial obtida pela Microsoft.
- O perfil solicitado (Ryzen 9 9950X3D, RTX 3060, 16 GB RAM, 256 GB + 1 TB) é uma configuração-alvo, não hardware que o Codespaces possa fornecer.

## Estrutura

- `scripts/check-host.sh`: verifica recursos e suporte a KVM.
- `scripts/optimize.sh`: limpeza leve e segura do ambiente Linux.
- `scripts/start.sh`: verifica pré-requisitos antes de iniciar uma VM QEMU.
- `config/pc.json`: perfil de configuração pretendido.
- `vm/`: local reservado para a ISO e disco virtual (não versionar arquivos grandes).
- `logs/`: logs locais.

## Começar no Codespaces

```bash
chmod +x scripts/*.sh
./scripts/check-host.sh
```

Se `/dev/kvm` não existir ou não for acessível, o Codespaces não poderá oferecer aceleração KVM neste ambiente. Não tente contornar restrições do host.

## Em uma máquina Linux própria com KVM

1. Instale QEMU/KVM e `qemu-system-x86`.
2. Coloque uma ISO oficial e licenciada do Windows 11 em `vm/windows11.iso`.
3. Ajuste `config/pc.json` para os recursos realmente disponíveis no host.
4. Execute `./scripts/start.sh`.

O script de inicialização é intencionalmente conservador e só inicia quando KVM, QEMU e a ISO estão presentes. Acesso remoto via navegador (noVNC) deve ser configurado depois que a VM funcionar localmente.

## Segurança

Não coloque senhas, chaves de API, tokens ou imagens ISO no Git. Use Secrets do Codespaces para segredos e mantenha `vm/` fora do controle de versão.
